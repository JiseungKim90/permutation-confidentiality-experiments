"""JOTA: quantization fingerprinting + sparsity detection (R20 + R56)."""
import os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.environ.get("JOB_OUTPUT_DIR", os.path.join(HERE, "output"))
os.makedirs(OUTPUT_DIR, exist_ok=True)

SCRIPT = os.path.join(HERE, "scripts", "22b_property_inference.py")
RUNS = [
    ("resnet20", os.path.join(HERE, "models", "resnet20_seed0.pt"),
     os.path.join(OUTPUT_DIR, "property_inference_r20.json")),
    ("resnet56", os.path.join(HERE, "models", "resnet56_seed0.pt"),
     os.path.join(OUTPUT_DIR, "property_inference_r56.json")),
]

def preflight():
    missing = [SCRIPT] if not os.path.isfile(SCRIPT) else []
    missing += [p for _, p, _ in RUNS if not os.path.isfile(p)]
    if missing: print("[preflight] MISSING:", missing); sys.exit(2)
    print("[preflight] OK", flush=True)

if __name__ == "__main__":
    print("=" * 70)
    print("JOTA: property inference (quantization + sparsity) R20 + R56")
    print(f"OUTPUT_DIR={OUTPUT_DIR}")
    print("=" * 70)
    preflight()
    t0 = time.time()
    for arch, teacher, out in RUNS:
        cmd = [sys.executable, "-u", SCRIPT,
               "--teacher-path", teacher,
               "--architecture", arch,
               "--output-path", out,
               "--precisions", "4,16,64,256",
               "--prune-amount", "0.5"]
        print(f"[run] {arch}", flush=True)
        r = subprocess.run(cmd, cwd=HERE)
        if r.returncode != 0: sys.exit(r.returncode)
        print(f"RESULT: {out}  ({os.path.getsize(out)} bytes)")
    print(f"[done] wall={time.time()-t0:.1f}s", flush=True)
