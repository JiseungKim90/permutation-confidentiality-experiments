"""JOTA: multi-query k-averaging attack (fixed permutation SAFHIRE)."""
import os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.environ.get("JOB_OUTPUT_DIR", os.path.join(HERE, "output"))
os.makedirs(OUTPUT_DIR, exist_ok=True)

SCRIPT  = os.path.join(HERE, "scripts", "21_multi_query_averaging.py")
TEACHER = os.path.join(HERE, "models", "resnet20_seed0.pt")
OUT     = os.path.join(OUTPUT_DIR, "multi_query_avg_r20.json")

CMD = [sys.executable, "-u", SCRIPT,
       "--teacher-path", TEACHER,
       "--architecture", "resnet20",
       "--output-path", OUT,
       "--precision", "256",
       "--noise-mults", "100,300,700,1000",
       "--k-values", "1,3,5,10,20",
       "--n-cols", "50",
       "--n-trials", "20"]

def preflight():
    missing = [p for p in [SCRIPT, TEACHER] if not os.path.isfile(p)]
    if missing: print("[preflight] MISSING:", missing); sys.exit(2)
    print("[preflight] OK", flush=True)

if __name__ == "__main__":
    print("=" * 70)
    print("JOTA: multi-query averaging R20, k in {1,3,5,10,20}, nm in {100,300,700,1000}")
    print(f"OUTPUT_DIR={OUTPUT_DIR}")
    print("=" * 70)
    preflight()
    t0 = time.time()
    r = subprocess.run(CMD, cwd=HERE)
    print(f"[done] wall={time.time()-t0:.1f}s rc={r.returncode}", flush=True)
    if r.returncode != 0: sys.exit(r.returncode)
    print(f"RESULT: {OUT}  ({os.path.getsize(OUT)} bytes)")
