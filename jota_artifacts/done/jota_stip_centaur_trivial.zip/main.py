"""JOTA entrypoint: zero-query recovery demo for STIP/Centaur threat model."""
import os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.environ.get("JOB_OUTPUT_DIR", os.path.join(HERE, "output"))
os.makedirs(OUTPUT_DIR, exist_ok=True)

SCRIPT = os.path.join(HERE, "scripts", "20_stip_centaur_trivial.py")

RUNS = [
    ("resnet20", os.path.join(HERE, "models", "resnet20_seed0.pt"),
     os.path.join(OUTPUT_DIR, "stip_centaur_r20.json")),
    ("resnet56", os.path.join(HERE, "models", "resnet56_seed0.pt"),
     os.path.join(OUTPUT_DIR, "stip_centaur_r56.json")),
]

def preflight():
    missing = [p for _, p, _ in RUNS if not os.path.isfile(p)]
    missing += [SCRIPT] if not os.path.isfile(SCRIPT) else []
    if missing: print("[preflight] MISSING:", missing); sys.exit(2)
    print("[preflight] OK", flush=True)

if __name__ == "__main__":
    print("=" * 70)
    print("JOTA: STIP/Centaur zero-query recovery (R20 + R56)")
    print(f"OUTPUT_DIR={OUTPUT_DIR}")
    print("=" * 70)
    preflight()
    t0 = time.time()
    for arch, teacher, out_path in RUNS:
        cmd = [sys.executable, "-u", SCRIPT,
               "--teacher-path", teacher,
               "--architecture", arch,
               "--output-path", out_path,
               "--precision", "256"]
        print(f"[run] {arch}", flush=True)
        r = subprocess.run(cmd, cwd=HERE)
        if r.returncode != 0: sys.exit(r.returncode)
        print(f"RESULT: {out_path}  ({os.path.getsize(out_path)} bytes)")
    print(f"[done] wall={time.time()-t0:.1f}s", flush=True)
